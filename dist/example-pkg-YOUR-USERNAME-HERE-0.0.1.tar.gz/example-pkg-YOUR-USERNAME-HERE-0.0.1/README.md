# single-cell-tools
Set of scripts that facilitate single cell rna-seq analysis

https://macanpn.github.io/single-cell-tools/namespacesc-analyses.html
